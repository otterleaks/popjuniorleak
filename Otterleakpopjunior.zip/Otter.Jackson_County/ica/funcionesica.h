
class master_funcionesica
{
	tag = "ica";
	class clientserver
	{
		file = "ica\funciones\clientserver";
		class varToServer {};
		class varUpdate {};
		class varToClient {};
	};
	class jugador
	{
		file = "ica\jugador";
		class vistaBonita {};
		class SonidosPolicia {};
		class vehiculoasiento {};
		class vehiculoasientocargo {};
		class vehiculochkClase {};
		class vehiculoIdentificar {};
		class vehiculoLimpiar {};
		class vehiculoValidar {};
		class SonidosNewSiren {};
		class quitopuntos {};
		class confiscar {};
		class debug {};
	};
};
