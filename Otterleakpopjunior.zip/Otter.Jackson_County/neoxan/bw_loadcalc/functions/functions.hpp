class BWLoadCalc
{
    class BW_Functions
    {
        file = "Neoxan\BW_LoadCalc\functions";
        class MotherLoad_Display {}; 		
		class GEARMONITOR {};
		class WEIGHTMONITOR {};
		class Init {postInit = 1;};

    };
};  
