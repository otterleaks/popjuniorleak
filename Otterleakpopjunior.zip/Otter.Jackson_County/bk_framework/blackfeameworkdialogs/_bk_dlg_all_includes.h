

// ***********************************************************
// PoP Police framework by Blakord
// All dialogs includes
// ***********************************************************

#include "Dlg_Actions_All.hpp"
#include "Dlg_Medico.hpp"