
// Importar en el editor con CTRL + I y poner: configfile >> "NombreDelDialogo"

class MyHelloWorldDialog {
	idd = -1;
	movingEnable = 0;
	class controlsBackground { 
		// define controls here
	};
	class objects { 
		// define controls here
	};
	class controls { 
		// define controls here







	};
};