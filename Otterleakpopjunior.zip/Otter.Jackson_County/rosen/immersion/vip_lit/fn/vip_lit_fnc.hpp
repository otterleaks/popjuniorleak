class vip_lit {

	tag = "vip_lit";
	
	class LittleImmersionTweaks {
	
		file = "rosen\immersion\vip_lit\fn";
		
		class cl_diary {};
		class cl_lighting {};
		class cl_mapOpen {};
		class cl_mapRainLoop {};
	};
};