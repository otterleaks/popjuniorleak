class vip_cmn {

	tag = "vip_cmn";
	
	class Common {
	
		file = "rosen\immersion\vip_cmn\fn";
		
		class gl_message {};

		class cl_authorDiaryTopic {};
		class cl_3DModelEdges {};
		class cl_diceRoll {};
		class cl_getSide {};
		class cl_keyBind {};
		class cl_profileColoursHTML {};
		class cl_randomPos {};
		class cl_randomSign {};
		class cl_vectorAverage {};
	};
};