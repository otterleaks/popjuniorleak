class testDroNeg {
	idd = -1;
	movingenable = true;
	
	class controls {
		class foto: RscPicture {
			type = CT_STATIC;
			style = ST_PICTURE;
			text = "ica\tests\testDroNeg.paa";

			idc = -1;
			x = 0.295762 * safezoneW + safezoneX;
			y = 0.0754 * safezoneH + safezoneY;
			w = 0.408476 * safezoneW;
			h = 0.8426 * safezoneH;
		};
	};
};