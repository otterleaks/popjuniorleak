
class life_admin_menu
{
	idd = 2900;
    name= "Consola De Admin";
    movingEnable = 0;
    enableSimulation = 1;
    onLoad = "[] spawn life_fnc_adminMenu;";

	class controls {

		class background: IGUIBack
		{
			idc = 3600;

			x = 0.204031 * safezoneW + safezoneX;
			y = 0.1546 * safezoneH + safezoneY;
			w = 0.523875 * safezoneW;
			h = 0.7238 * safezoneH;
		};
		class header: RscStructuredText
		{
			idc = 3607;

			x = 0.204031 * safezoneW + safezoneX;
			y = 0.1216 * safezoneH + safezoneY;
			w = 0.523875 * safezoneW;
			h = 0.033 * safezoneH;
			colorText[] = {1,1,1,1};
			colorBackground[] = {0,0,0,0.75};
		};
        class PlayerList_Admin: Life_RscListBox {
            idc = 2902;
            text = "";
            sizeEx = 0.035;
            onLBSelChanged = "[_this] spawn life_fnc_adminQuery";
            x = 0.207123 * safezoneW + safezoneX;
			y = 0.159 * safezoneH + safezoneY;
			w = 0.262969 * safezoneW;
			h = 0.6666 * safezoneH;
        };
		class PlayerBInfo: Life_RscStructuredText {
            idc = 2903;
            text = "";
            x = 0.473644 * safezoneW + safezoneX;
            y = 0.163925 * safezoneH + safezoneY;
            w = 0.250386 * safezoneW;
            h = 0.350078 * safezoneH;
            colorBackground[] = {0,0,0,0.7};
        };
		//XD
		class traer: RscButton
		{
			idc = 4704;
			text = "Traer";
			x = 0.473644 * safezoneW + safezoneX;
			y = 0.528006 * safezoneH + safezoneY;
			w = 0.065891 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminTPtoME;";
			tooltip = "Traer al jugador seleccionado";
		};

		class voy: RscButton
		{
			idc = 4705;
			text = "Ir";
			x = 0.552713 * safezoneW + safezoneX;
			y = 0.528006 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminTPtoPL;";
			tooltip = "Ir al jugador seleccionado";
		};

		class mtp: RscButton
		{
			idc = 4706;
			text = "Mapa TP";
			x = 0.64496 * safezoneW + safezoneX;
			y = 0.528006 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminTeleport;";
			tooltip = "Mapa Tp";
		};

		class congelar: RscButton
		{
			idc = 4707;
			text = "Congelar";
			x = 0.473644 * safezoneW + safezoneX;
			y = 0.584019 * safezoneH + safezoneY;
			w = 0.065891 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminFreeze;";
			tooltip = "congelar";
		};

		class curar: RscButton
		{
			idc = 4708;
			text = "Curar";
			x = 0.552713 * safezoneW + safezoneX;
			y = 0.584019 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminHR;";
			tooltip = "Curar/Reparar";
		};

		class godmode: RscButton
		{
			idc = 4709;
			text = "Godmode";
			x = 0.64496 * safezoneW + safezoneX;
			y = 0.584019 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminuni;";
			tooltip = "godmode";
		};
		
		class infectar: RscButton
		{
			idc = 4710;
			text = "Map Markers";
			x = 0.473644 * safezoneW + safezoneX;
			y = 0.640031 * safezoneH + safezoneY;
			w = 0.065891 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] spawn life_fnc_adminMarkers;";
			tooltip = "Marcadores de Mapa";
		};

		class invisible: RscButton
		{
			idc = 4711;
			text = "Invisible";
			x = 0.552713 * safezoneW + safezoneX;
			y = 0.640031 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[player, true, true] call ica_fnc_ocultame;";
			tooltip = "Invisible";
		};

		class espectear: RscButton
		{
			idc = 4712;
			text = "Espectear";
			x = 0.64496 * safezoneW + safezoneX;
			y = 0.640031 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminSpectate;";
			tooltip = "espectear";
		};
		
		class kill: RscButton
		{
			idc = 4713;
			text = "Kill";
			x = 0.473644 * safezoneW + safezoneX;
			y = 0.696044 * safezoneH + safezoneY;
			w = 0.065891 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminKill;";
			tooltip = "/Kill";
		};
		
		class licencias: RscButton
		{
			idc = 4714;
			text = "Licencias";
			x = 0.552713 * safezoneW + safezoneX;
			y = 0.696044 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminLicencias;";
			tooltip = "Cursor Licencias";
		};
		
		class borrar: RscButton
		{
			idc = 4715;
			text = "Borrar";
			x = 0.64496 * safezoneW + safezoneX;
			y = 0.696044 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420094 * safezoneH;
			onButtonClick = "[] call life_fnc_adminDelObj;";
			tooltip = "Borrar Cursor";
		};
		
		class revivir: RscButton
		{
			idc = 4718;
			text = "Revivir";
			x = 0.644911 * safezoneW + safezoneX;
			y = 0.752892 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420093 * safezoneH;
			onButtonClick = "[] call life_fnc_adminRevivir;";
			tooltip = "Revivir";
		};

		class esposar: RscButton
		{
			idc = 4719;
			text = "Llaves";
			x = 0.473606 * safezoneW + safezoneX;
			y = 0.752012 * safezoneH + safezoneY;
			w = 0.0672801 * safezoneW;
            h = 0.0439812 * safezoneH;
			onButtonClick = "[] call life_fnc_adminKeys;";
			tooltip = "Dar llaves";
		};
		
		class desesposar: RscButton
		{
			idc = 4720;
			text = "Cachear";
			x = 0.551754 * safezoneW + safezoneX;
			y = 0.752892 * safezoneH + safezoneY;
			w = 0.0790693 * safezoneW;
            h = 0.0420093 * safezoneH;
			onButtonClick = "[call compile format ['%1', (lbData [2902, lbCurSel (2902)])]] spawn ica_fnc_cacheo;";
			tooltip = "Cachear Jugador";
		};
		
	};
};
