class menuY
{
	idd = -1;
	movingenable = true;
	onLoad = "uiNamespace setVariable ['menuY', _this select 0]; ";
	onUnLoad = "uiNamespace setVariable ['menuY', nil]; ";
	
	class controls {
		class i1: RscPicture
		{
			idc = 7040;

			text = "";
			x = 0.958906 * safezoneW + safezoneX;
			y = 0.676 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class i2: RscPicture
		{
			idc = 7041;

			text = "";
			x = 0.958906 * safezoneW + safezoneX;
			y = 0.621 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class i3: RscPicture
		{
			idc = 7042;

			text = "";
			x = 0.958906 * safezoneW + safezoneX;
			y = 0.566 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class i4: RscPicture
		{
			idc = 7043;

			text = "";
			x = 0.958906 * safezoneW + safezoneX;
			y = 0.511 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class i5: RscPicture
		{
			idc = 7044;

			text = "";
			x = 0.958906 * safezoneW + safezoneX;
			y = 0.456 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class i6: RscPicture
		{
			idc = 7045;

			text = "";
			x = 0.958906 * safezoneW + safezoneX;
			y = 0.401 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
		};
		class b1: RscButtonsoso
		{
			idc = 7046;

			x = 0.958906 * safezoneW + safezoneX;
			y = 0.676 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {0,0,0,0};
			colorBackgroundActive[] = {0.8, 0.8, 0.8, 0.3};
			colorBackgroundDisabled[] = {0, 0, 0, 0};
		};
		class b2: RscButtonsoso
		{
			idc = 7047;

			x = 0.958906 * safezoneW + safezoneX;
			y = 0.621 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {0,0,0,0};
			colorBackgroundActive[] = {0.8, 0.8, 0.8, 0.3};
			colorBackgroundDisabled[] = {0, 0, 0, 0};
		};
		class b3: RscButtonsoso
		{
			idc = 7048;

			x = 0.958906 * safezoneW + safezoneX;
			y = 0.566 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {0,0,0,0};
			colorBackgroundActive[] = {0.8, 0.8, 0.8, 0.3};
			colorBackgroundDisabled[] = {0, 0, 0, 0};
		};
		class b4: RscButtonsoso
		{
			idc = 7049;

			x = 0.958906 * safezoneW + safezoneX;
			y = 0.511 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {0,0,0,0};
			colorBackgroundActive[] = {0.8, 0.8, 0.8, 0.3};
			colorBackgroundDisabled[] = {0, 0, 0, 0};
		};
		class b5: RscButtonsoso
		{
			idc = 7050;

			x = 0.958906 * safezoneW + safezoneX;
			y = 0.456 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {0,0,0,0};
			colorBackgroundActive[] = {0.8, 0.8, 0.8, 0.3};
			colorBackgroundDisabled[] = {0, 0, 0, 0};
		};
		class b6: RscButtonsoso
		{
			idc = 7051;

			x = 0.958906 * safezoneW + safezoneX;
			y = 0.401 * safezoneH + safezoneY;
			w = 0.0257812 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {0,0,0,0};
			colorBackgroundActive[] = {0.8, 0.8, 0.8, 0.3};
			colorBackgroundDisabled[] = {0, 0, 0, 0};
		};
	};
};