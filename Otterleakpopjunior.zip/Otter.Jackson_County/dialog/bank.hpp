class Life_atm_management {
	idd = 2700;
	name= "life_atm_menu";
	movingEnable = false;
	enableSimulation = true;
	
	class controlsBackground {
		class Title : Life_RscTitle {			
			idc = -1;
			text = "$STR_ATM_Title";
			x = 0.324246 * safezoneW + safezoneX;
			y = 0.28 * safezoneH + safezoneY;
			w = 0.351508 * safezoneW;
			h = 0.033 * safezoneH;
			colorBackground[] = {0,0,0,0.8};
		};

		class balancebg: Life_RscText
		{
			idc = -1;
			x = 0.324246 * safezoneW + safezoneX;
			y = 0.324 * safezoneH + safezoneY;
			w = 0.160246 * safezoneW;
			h = 0.143 * safezoneH;
			colorBackground[] = {0,0,0,0.8};
		};
		class sendbg: Life_RscText
		{
			idc = -1;
			x = 0.489662 * safezoneW + safezoneX;
			y = 0.324 * safezoneH + safezoneY;
			w = 0.186092 * safezoneW;
			h = 0.308 * safezoneH;
			colorBackground[] = {0,0,0,0.8};
		};
	};
	
	class controls {

		class CashTitle : Life_RscStructuredText
		{
			idc = 2701;
			text = "";
			
			x = 0.329416 * safezoneW + safezoneX;
			y = 0.335 * safezoneH + safezoneY;
			w = 0.149908 * safezoneW;
			h = 0.088 * safezoneH;
		};		
				
		class WithdrawButton : Life_RscShopButton 
		{
			idc = -1;
			text = "$STR_ATM_Withdraw";			
			onButtonClick = "[] call life_fnc_bankWithdraw";
			
			x = 0.324246 * safezoneW + safezoneX;
			y = 0.478 * safezoneH + safezoneY;
			w = 0.0775384 * safezoneW;
			h = 0.044 * safezoneH;
		};
		
		class DepositButton : Life_RscShopButton 
		{
			idc = -1;
			text = "$STR_ATM_Deposit";			
			onButtonClick = "[] call life_fnc_bankDeposit";
			
			x = 0.406954 * safezoneW + safezoneX;
			y = 0.478 * safezoneH + safezoneY;
			w = 0.0775384 * safezoneW;
			h = 0.044 * safezoneH;
		};
		
		class moneyEdit : Life_RscEdit {		
			idc = 2702;
			text = "1";
		
			x = 0.329416 * safezoneW + safezoneX;
			y = 0.434 * safezoneH + safezoneY;
			w = 0.149908 * safezoneW;
			h = 0.022 * safezoneH;
		
		};
		
		class PlayerList : Life_RscListBox 
		{
			idc = 2703;
			
			sizeEx = "(((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 0.75)";
			x = 0.494831 * safezoneW + safezoneX;
			y = 0.335 * safezoneH + safezoneY;
			w = 0.175754 * safezoneW;
			h = 0.242 * safezoneH;
		};
		
		class TransferButton : Life_RscShopButton 
		{
			idc = -1;
			text = "$STR_ATM_Transfer";			
			onButtonClick = "[] call life_fnc_bankTransfer";
			
			x = 0.5672 * safezoneW + safezoneX;
			y = 0.588 * safezoneH + safezoneY;
			w = 0.103385 * safezoneW;
			h = 0.033 * safezoneH;
		};
		
	};
};